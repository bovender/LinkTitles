<?php
/*! @file LinkTitles.i18n.magic.php
 */
 
/// Holds the two magic words that the extension provides.
$magicWords = array();

/// Default magic words in English.
$magicWords['en'] = array(
	'MAG_LINKTITLES_NOAUTOLINKS' => array(0, '__NOAUTOLINKS__'),
	'MAG_LINKTITLES_NOTARGET' => array(0, '__NOAUTOLINKTARGET__')
);

