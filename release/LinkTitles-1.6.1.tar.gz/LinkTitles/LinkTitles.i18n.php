<?php
/*! \file LinkTitles.i18n.php
 */
 
$messages = array();

$messages['en'] = array(
	'linktitles-desc' => 'Automatically adds links to existing pages whenever a page is saved.',
);

$messages['de'] = array(
	'linktitles-desc' => 'Fügt beim Speichern von Seiten automatisch Querverweise zu vorhandenen Seiten ein.',
);
