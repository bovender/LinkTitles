<?php
/*! \file LinkTitles.i18n.magic.php
 */
 
$magicWords = array();

$magicWords['en'] = array(
	'MAG_LINKTITLES_NOAUTOLINKS' => array(0, '__NOAUTOLINKS__')
);

