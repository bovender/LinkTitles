LinkTitles
==========

MediaWiki extension that automatically adds links to words that match titles of existing pages.

For more information, see http://www.mediawiki.org/wiki/Extension:LinkTitles

Source code documentation can be found at the [Github project
pages](http://bovender.github.io/LinkTitles).

