LinkTitles
==========

MediaWiki extension that automatically adds links to words that match titles of existing pages.

For more information, see http://www.mediawiki.org/wiki/Extension:LinkTitles

Minimum requirements: MediaWiki 1.21+, PHP 5.3

Source code documentation can be found at the [Github project
pages](http://bovender.github.io/LinkTitles).

